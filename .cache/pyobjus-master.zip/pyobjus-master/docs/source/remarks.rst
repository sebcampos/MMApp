.. _remarks:

Remarks
=======

Missing things
--------------

- Support for bit fields -> libffi restriction
- Support for passing unions by value -> libffi restriction

Issues
------

- Currently there is only support for few structure, union and enumeration types.
